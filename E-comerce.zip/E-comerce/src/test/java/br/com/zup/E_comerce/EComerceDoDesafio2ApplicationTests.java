package br.com.zup.E_comerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EComerceDoDesafio2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
